#!/bin/bash
whoami

echo 'export PATH=$PATH:/usr/local/go/bin' >> ~/.bashrc && source ~/.bashrc

# sudo echo "nameserver 1.1.1.1" > /etc/resolv.conf

# sudo ip link set dev wg-server mtu 1200

# cài đặt nodejs
 curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
 export NVM_DIR="$([ -z "${XDG_CONFIG_HOME-}" ] && printf '%s/.nvm' "${HOME}" || printf '%s/nvm' "${XDG_CONFIG_HOME}")"
 [ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh" # This loads nvm
 [ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion" # This loads nvm bash completion
 nvm install 14
 nvm use 14

# --------------------- test voi lite-tunel seft host

#git clone https://github.com/alexTvirus/wstunel-client.git

# wstunnel -s 0.0.0.0:9988 -t 0.0.0.0:5901 &

#git clone https://github.com/alexTvirus/lite-http-tunnel-client.git

#bash /home/user/lite-http-tunnel-client/lite-http-tunnel config server https://neighborly-tungsten-microwave.glitch.me/
#bash /home/user/lite-http-tunnel-client/lite-http-tunnel auth abc abc
#bash /home/user/lite-http-tunnel-client/lite-http-tunnel start 6080 &
# -------------------

unzip /home/user/server.zip

(cd /home/user/server/go-server && sudo /usr/local/go/bin/go mod tidy)

# -------------------

vncserver -passwd /home/user/.vnc/passwd :1  &

# -------------------

# exec java -Dfile.encoding=UTF-8 -jar /ServerWebSocket-vnc.jar 6666 5901 &

# exec java -Dfile.encoding=UTF-8 -jar /jstunserver.jar &

# -------------------

# /opt/linux/core \
#     -i 10.144.144.2 \
#     --exit-nodes 10.144.144.1 \
#     -d \
#     --network-name "my-secret-net-asdasd123" \
#     --network-secret "123123" \
#     --hostname "linux-symmetric" \
#     -p wss://pressed-activated-them-perfume.trycloudflare.com   &


# -------

websockify --web /usr/share/novnc/ 6080 127.0.0.1:5901
